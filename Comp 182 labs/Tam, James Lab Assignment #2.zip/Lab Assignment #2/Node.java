/*
Name: James Tam
Date created or Date last modified:09/20/2015
Project info: Lab Assignment #2, Linked list of Integers
Description: Write a program to create and maintain a linked list of integers */
class Node 
{


 private int number;

 private Node next;

 public Node(int n) 
 {
  this.number = n; // this number
  this.next = null; // this next
 }

 

 public Node getNext() 
 {
   return this.next; // return 
 }

 public int getNumber()
 {
   return this.number; // return 
 }

 public void setNext(Node n) 
 { 
   this.next = n;
 }
 
 public String toString() 
 {
   return this.number + (";"); // return the number
 }

}