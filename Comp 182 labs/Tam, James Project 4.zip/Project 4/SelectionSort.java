/*Name: James Tam
Date created or Date last modified: 11/18/2015
Project info: Project 4 - "Sorting and Complexity"
Description: Measures the growth rate of the different sort methods */
public class SelectionSort extends BasicSort{
   
   public SelectionSort() {
    super("SelectionSort");
    }
    
   @Override
   public void sort() {
      int i, j, minindex, tmp;
      int n = data.length;
      for(i = 0; i < n-1; i++) {
         minindex = i;
            for(j = i + 1; j < n;  j++) {
               if(data[j] < data[minindex]){
                minindex = j;
                }
            }
            if(minindex != i){
               tmp = data[i];
               data[i] = data[minindex];
               data[minindex]=tmp;
            }
      }
   }
}